# Facial-emotion-detector
Facial emotion detector using CNN 

DATA SET LINK - https://www.kaggle.com/jonathanoheix/face-expression-recognition-dataset
